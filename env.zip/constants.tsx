
import React from 'react';
import { Service, Project, Product } from './types';

export const COLORS = {
  primary: '#0052CC', // Blue
  secondary: '#28a745', // Green
  accent: '#fd7e14', // Orange
};

export const SERVICES: Service[] = [
  {
    id: 'it-infra',
    title: 'IT Infrastructure & Maintenance',
    category: 'IT/ELV',
    description: 'Complete server setup, rack management, and ongoing hardware maintenance for businesses of all sizes.',
    icon: 'fa-server',
    image: 'https://picsum.photos/seed/server/800/600'
  },
  {
    id: 'networking',
    title: 'Networking & WiFi Solutions',
    category: 'Networking',
    description: 'High-speed structured cabling, enterprise WiFi deployment, and robust network security.',
    icon: 'fa-network-wired',
    image: 'https://picsum.photos/seed/network/800/600'
  },
  {
    id: 'cctv',
    title: 'CCTV & Access Control',
    category: 'IT/ELV',
    description: 'Advanced IP surveillance systems and biometric access control for enhanced security.',
    icon: 'fa-video',
    image: 'https://picsum.photos/seed/security/800/600'
  },
  {
    id: 'repair',
    title: 'Laptop & Mobile Repair',
    category: 'Maintenance',
    description: 'Expert hardware diagnostics and repair for all major brands of laptops and mobile devices.',
    icon: 'fa-laptop-medical',
    image: 'https://picsum.photos/seed/repair/800/600'
  },
  {
    id: 'lv-systems',
    title: 'LV Systems Design',
    category: 'IT/ELV',
    description: 'Professional design, installation, and supervision for low voltage electrical systems.',
    icon: 'fa-bolt',
    image: 'https://picsum.photos/seed/electric/800/600'
  },
  {
    id: 'fitout',
    title: 'Interior Fitout Services',
    category: 'Interior',
    description: 'Technical coordination and technical services for modern office interiors and workspaces.',
    icon: 'fa-pencil-ruler',
    image: 'https://picsum.photos/seed/office/800/600'
  }
];

export const PROJECTS: Project[] = [
  { id: 'p1', name: 'Gemini', logo: 'https://picsum.photos/seed/gem/200/200', description: 'IT Infrastructure deployment' },
  { id: 'p2', name: 'Gulf Smelter', logo: 'https://picsum.photos/seed/gulf/200/200', description: 'Network security & CCTV' },
  { id: 'p3', name: 'Humble Home', logo: 'https://picsum.photos/seed/home/200/200', description: 'Smart home automation' },
  { id: 'p4', name: 'Al Jafiliya Tech', logo: 'https://picsum.photos/seed/tech/200/200', description: 'Annual Maintenance Contract' }
];

export const TESTIMONIALS = [
  {
    name: 'Ahmed K.',
    role: 'Operations Manager',
    content: 'Al Shah Solutions transformed our office connectivity. Their networking team is top-notch.',
    stars: 5
  },
  {
    name: 'Sarah M.',
    role: 'IT Director',
    content: 'We rely on them for all our hardware maintenance. Fast response and professional service.',
    stars: 5
  }
];
