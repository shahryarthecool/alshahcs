
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES, PROJECTS, TESTIMONIALS } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center bg-gray-900 text-white overflow-hidden">
        {/* Background Animation Elements */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-blue-600/20 to-transparent pointer-events-none"></div>
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-green-600/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in space-y-8">
              <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-widest">
                <span className="flex h-2 w-2 rounded-full bg-blue-500 mr-2 animate-pulse"></span>
                UAE Leading IT Solutions
              </div>
              <h1 className="text-5xl md:text-7xl font-extrabold leading-tight tracking-tight">
                Tech <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-green-400 to-orange-400">Innovations</span> for Your Business
              </h1>
              <p className="text-lg text-gray-400 max-w-lg leading-relaxed">
                Expert IT infrastructure, networking, and comprehensive maintenance solutions in Dubai. We build the digital foundation your business deserves.
              </p>
              <div className="flex flex-wrap gap-4 pt-4">
                <Link to="/contact" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all transform hover:-translate-y-1 shadow-lg shadow-blue-900/40">
                  Request a Quote
                </Link>
                <Link to="/services" className="px-8 py-4 bg-gray-800 hover:bg-gray-700 text-white border border-gray-700 rounded-xl font-bold transition-all transform hover:-translate-y-1">
                  Our Services
                </Link>
              </div>
            </div>
            <div className="hidden md:block relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500 border-4 border-gray-800">
                <img src="https://picsum.photos/seed/it-infra-hero/800/800" alt="Technology Hub" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 to-transparent"></div>
              </div>
              {/* Floating badges */}
              <div className="absolute -top-10 -right-10 bg-white p-6 rounded-2xl shadow-2xl z-20 animate-bounce duration-[3000ms]">
                <div className="text-blue-600 font-bold text-3xl">100+</div>
                <div className="text-gray-500 text-sm">Projects Delivered</div>
              </div>
              <div className="absolute -bottom-6 -left-10 bg-green-500 p-6 rounded-2xl shadow-2xl z-20 animate-pulse">
                <i className="fa-solid fa-shield-halved text-white text-3xl"></i>
                <div className="text-white font-bold text-sm mt-2">Certified Security</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Highlight */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-blue-600 font-bold tracking-widest uppercase text-sm">What We Do</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold text-gray-900">Premium Technical Services</h3>
            <p className="text-gray-500 max-w-2xl mx-auto">From structured cabling to high-end server maintenance, we provide end-to-end technical excellence.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {SERVICES.slice(0, 3).map((service, index) => (
              <div key={service.id} className="group p-8 rounded-3xl bg-gray-50 border border-gray-100 hover:border-blue-200 transition-all hover:shadow-2xl hover:shadow-blue-500/5 transform hover:-translate-y-2">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-2xl text-white mb-6 bg-blue-600 shadow-lg group-hover:scale-110 transition-transform`}>
                  <i className={`fa-solid ${service.icon}`}></i>
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">{service.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>
                <Link to="/services" className="text-blue-600 font-bold text-sm inline-flex items-center group-hover:gap-2 transition-all">
                  Learn More <i className="fa-solid fa-arrow-right ml-2"></i>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section className="py-24 bg-gray-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div className="space-y-4">
              <h2 className="text-green-600 font-bold tracking-widest uppercase text-sm">Our Work</h2>
              <h3 className="text-4xl font-extrabold text-gray-900">Clients Who Trust Us</h3>
            </div>
            <Link to="/about" className="px-6 py-3 border-2 border-gray-200 hover:border-blue-600 hover:text-blue-600 rounded-full font-bold transition-all">
              View Case Studies
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {PROJECTS.map((project) => (
              <div key={project.id} className="flex flex-col items-center group">
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 w-full aspect-square flex items-center justify-center group-hover:shadow-xl transition-all mb-4 grayscale hover:grayscale-0">
                   <img src={project.logo} alt={project.name} className="max-w-full h-auto opacity-70 group-hover:opacity-100 transition-opacity" />
                </div>
                <span className="font-bold text-gray-900">{project.name}</span>
                <span className="text-xs text-gray-500 uppercase tracking-tighter">{project.description}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-blue-900 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-10">
          <i className="fa-solid fa-quote-right text-[200px]"></i>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold">What Our Partners Say</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            {TESTIMONIALS.map((t, idx) => (
              <div key={idx} className="bg-white/5 backdrop-blur-lg border border-white/10 p-10 rounded-3xl">
                <div className="flex text-orange-400 mb-6">
                  {[...Array(t.stars)].map((_, i) => <i key={i} className="fa-solid fa-star text-sm mr-1"></i>)}
                </div>
                <p className="text-xl italic mb-8 leading-relaxed">"{t.content}"</p>
                <div>
                  <div className="font-bold text-lg">{t.name}</div>
                  <div className="text-blue-400 text-sm uppercase font-bold tracking-wider">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-[2.5rem] p-12 md:p-20 text-center text-white relative overflow-hidden shadow-2xl">
            <div className="relative z-10 space-y-8">
              <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight">Ready to Upgrade Your <br className="hidden md:block"/> Infrastructure?</h2>
              <p className="text-blue-100 text-lg max-w-2xl mx-auto">Contact us today for a free technical consultation and a personalized quote for your project.</p>
              <div className="pt-4">
                <Link to="/contact" className="bg-white text-blue-600 px-10 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-transform shadow-xl">
                  Contact Us Now
                </Link>
              </div>
            </div>
            <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M0,0 L100,0 L100,100 L0,100 Z" fill="url(#grid-pattern)" />
                <defs>
                  <pattern id="grid-pattern" width="10" height="10" patternUnits="userSpaceOnUse">
                    <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  </pattern>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
