
import React from 'react';

const Store: React.FC = () => {
  const dummyProducts = [
    { id: 1, name: 'Enterprise Network Router', price: 'AED 1,200', image: 'https://picsum.photos/seed/router/400/400', category: 'Hardware' },
    { id: 2, name: 'IP Security Camera 4K', price: 'AED 450', image: 'https://picsum.photos/seed/cctv-prod/400/400', category: 'Security' },
    { id: 3, name: 'Ergonomic Office Chair', price: 'AED 850', image: 'https://picsum.photos/seed/chair/400/400', category: 'Furniture' },
    { id: 4, name: 'High-Speed Patch Cable Bundle', price: 'AED 150', image: 'https://picsum.photos/seed/cables/400/400', category: 'Accessories' },
  ];

  return (
    <div className="bg-white min-h-screen">
      <section className="bg-orange-500 py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-extrabold mb-4">Al Shah Tech Store</h1>
          <p className="text-orange-100 text-lg">Official IT Hardware & Furniture - Coming Soon!</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
          <h2 className="text-3xl font-bold text-gray-900">Featured Products</h2>
          <div className="flex gap-2">
            <span className="px-4 py-2 bg-blue-100 text-blue-600 rounded-full text-xs font-bold">ALL</span>
            <span className="px-4 py-2 bg-gray-100 text-gray-500 rounded-full text-xs font-bold hover:bg-blue-100 hover:text-blue-600 transition-colors cursor-pointer">HARDWARE</span>
            <span className="px-4 py-2 bg-gray-100 text-gray-500 rounded-full text-xs font-bold hover:bg-blue-100 hover:text-blue-600 transition-colors cursor-pointer">FURNITURE</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {dummyProducts.map((p) => (
            <div key={p.id} className="group bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-xl transition-all">
              <div className="h-64 bg-gray-50 relative overflow-hidden">
                <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute top-4 right-4 bg-white/90 px-3 py-1 rounded-full text-[10px] font-black uppercase text-orange-600 tracking-widest shadow-sm">
                  {p.category}
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-gray-900 mb-2 truncate">{p.name}</h3>
                <div className="text-2xl font-black text-blue-600 mb-6">{p.price}</div>
                <button className="w-full py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-blue-600 transition-colors flex items-center justify-center gap-2">
                  <i className="fa-solid fa-cart-shopping"></i>
                  Notify Me
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-24 p-12 bg-gray-50 rounded-[3rem] border-2 border-dashed border-gray-200 text-center">
          <i className="fa-solid fa-store text-5xl text-gray-300 mb-6"></i>
          <h3 className="text-2xl font-bold text-gray-400">Full Store Integration Launching Q3 2024</h3>
          <p className="text-gray-400 mt-2">We're currently stocking our warehouse with the latest tech hardware and office furniture.</p>
        </div>
      </div>
    </div>
  );
};

export default Store;
